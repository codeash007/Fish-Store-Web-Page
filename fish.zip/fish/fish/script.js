
const SR7 = {
    PMH: {},
    currentSlide: 1,
    totalSlides: 0,
    isAnimating: false,
    autoPlayInterval: null,
    touchStartX: 0,
    touchEndX: 0
};

// Global variables
let isMenuOpen = false;
let hasUserInteracted = false;
let audioContext = null;

// Main initialization function
document.addEventListener('DOMContentLoaded', function() {
    console.log('🐟 Seafood Store Template Loaded Successfully! 🐟');
    
    // Initialize all features
    initializeSlider();
    initializeMenu();
    initializeInfoPanels();
    initializeNavigation();
    initializeSoundEffects();
    initializeVisualEffects();
    initializeResponsiveFeatures();
    fixImageLoading();
    addAnimations();
    addVisualEnhancements();
    initializeParticleEffects();
    initializeAdvancedAnimations();
    setupErrorHandling();
    
    // Start auto-play after initialization
    setTimeout(startAutoPlay, 1000);
});

// ==================== SLIDER FUNCTIONALITY ====================
function initializeSlider() {
    const slides = document.querySelectorAll('sr7-slide');
    SR7.totalSlides = slides.length;
    
    if (SR7.totalSlides === 0) return;
    
    // Show specific slide
    function showSlide(index) {
        if (SR7.isAnimating) return;
        
        SR7.isAnimating = true;
        SR7.currentSlide = index;
        
        slides.forEach((slide, i) => {
            const isActive = i === index;
            
            slide.style.visibility = isActive ? 'visible' : 'hidden';
            slide.style.display = isActive ? 'block' : 'none';
            slide.style.opacity = isActive ? '1' : '0';
            slide.style.zIndex = isActive ? '5' : '1';
            slide.style.pointerEvents = isActive ? 'auto' : 'none';
            
            // Add slide transition effects
            if (isActive) {
                slide.style.transform = 'translateX(0)';
                animateSlideContent(slide);
            } else {
                slide.style.transform = 'translateX(100%)';
            }
        });
        
        // Close all info panels when changing slides
        closeAllInfoPanels();
        
        // Update background based on current slide
        updateBackgroundTheme(index);
        
        setTimeout(() => {
            SR7.isAnimating = false;
        }, 800);
        
        // Play slide transition sound
        playSound('slide');
    }
    
    // Navigation functions (make them global)
    window.nextSlide = function() {
        if (SR7.isAnimating) return;
        const nextIndex = (SR7.currentSlide + 1) % SR7.totalSlides;
        showSlide(nextIndex);
    };
    
    window.prevSlide = function() {
        if (SR7.isAnimating) return;
        const prevIndex = SR7.currentSlide === 0 ? SR7.totalSlides - 1 : SR7.currentSlide - 1;
        showSlide(prevIndex);
    };
    
    // Initialize with current slide
    showSlide(SR7.currentSlide);
}

function animateSlideContent(slide) {
    const contentElements = slide.querySelectorAll('sr7-txt, sr7-img, sr7-btn');
    
    contentElements.forEach((element, index) => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            element.style.transition = 'all 0.6s ease';
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

function updateBackgroundTheme(slideIndex) {
    const themes = [
        'linear-gradient(135deg, #ff6b35, #ff8e35)', // Salmon
        'linear-gradient(135deg, #4a90e2, #7bb3f0)', // Halibut
        'linear-gradient(135deg, #e74c3c, #f39c12)', // Tuna
        'linear-gradient(135deg, #2ecc71, #27ae60)', // Sea Bass
        'linear-gradient(135deg, #9b59b6, #8e44ad)'  // Mackerel
    ];
    
    if (themes[slideIndex]) {
        document.body.style.background = themes[slideIndex];
    }
}

function startAutoPlay() {
    if (SR7.autoPlayInterval) clearInterval(SR7.autoPlayInterval);
    
    SR7.autoPlayInterval = setInterval(() => {
        if (!isMenuOpen && !document.querySelector('.info-panel.active')) {
            window.nextSlide();
        }
    }, 5000);
}

function stopAutoPlay() {
    if (SR7.autoPlayInterval) {
        clearInterval(SR7.autoPlayInterval);
        SR7.autoPlayInterval = null;
    }
}

// ==================== MENU FUNCTIONALITY ====================
function initializeMenu() {
    const menuToggle = document.getElementById('menuToggle');
    const menuPanel = document.getElementById('menuPanel');
    const menuIcon = menuToggle?.querySelector('.material-icons');
    const menuText = menuToggle?.querySelector('span');
    
    if (!menuToggle || !menuPanel) return;
    
    menuToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleMenu();
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!menuToggle.contains(e.target) && !menuPanel.contains(e.target) && isMenuOpen) {
            closeMenu();
        }
    });
    
    // Menu item hover effects
    const menuItems = menuPanel.querySelectorAll('.menu-item');
    menuItems.forEach((item, index) => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(-10px) scale(1.05)';
            playSound('hover');
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0) scale(1)';
        });
        
        // Add click sound
        item.addEventListener('click', function() {
            playSound('click');
        });
    });
    
    function toggleMenu() {
        isMenuOpen = !isMenuOpen;
        hasUserInteracted = true;
        
        if (isMenuOpen) {
            openMenu();
        } else {
            closeMenu();
        }
    }
    
    function openMenu() {
        menuPanel.classList.add('active');
        if (menuIcon) {
            menuIcon.textContent = 'close';
            menuIcon.style.transform = 'rotate(180deg)';
        }
        if (menuText) menuText.textContent = 'close';
        
        stopAutoPlay();
        playSound('click');
        
        // Animate menu items
        const menuItems = menuPanel.querySelectorAll('.menu-item');
        menuItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateX(50px)';
            
            setTimeout(() => {
                item.style.transition = 'all 0.5s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateX(0)';
            }, index * 100);
        });
    }
    
    function closeMenu() {
        isMenuOpen = false;
        menuPanel.classList.remove('active');
        if (menuIcon) {
            menuIcon.textContent = 'menu';
            menuIcon.style.transform = 'rotate(0deg)';
        }
        if (menuText) menuText.textContent = 'menu';
        
        startAutoPlay();
    }
    
    // Make closeMenu globally available
    window.closeMenu = closeMenu;
}

// ==================== INFO PANELS FUNCTIONALITY ====================
function initializeInfoPanels() {
    const infoTags = document.querySelectorAll('.info-tag');
    const fishImages = document.querySelectorAll('sr7-img[id*="-8"]');
    const infoPanels = document.querySelectorAll('.info-panel');
    
    // Toggle info panel for specific slide
    function toggleInfoPanel(slideElement) {
        const infoPanel = slideElement.querySelector('.info-panel');
        if (!infoPanel) return;
        
        const isActive = infoPanel.classList.contains('active');
        
        // Close all info panels first
        closeAllInfoPanels();
        
        // Toggle current panel
        if (!isActive) {
            infoPanel.classList.add('active');
            infoPanel.style.opacity = '1';
            infoPanel.style.visibility = 'visible';
            infoPanel.style.transform = 'translateY(-50%) translateX(0)';
            
            stopAutoPlay();
            playSound('click');
            animateInfoContent(infoPanel);
        } else {
            startAutoPlay();
        }
    }
    
    // Animate info panel content
    function animateInfoContent(panel) {
        const items = panel.querySelectorAll('sr7-txt');
        items.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateX(20px)';
            
            setTimeout(() => {
                item.style.transition = 'all 0.3s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateX(0)';
            }, index * 50);
        });
    }
    
    // Add click events to info tags
    infoTags.forEach(tag => {
        tag.addEventListener('click', function(e) {
            e.stopPropagation();
            hasUserInteracted = true;
            const slide = this.closest('sr7-slide');
            if (slide) {
                toggleInfoPanel(slide);
            }
        });
        
        // Add hover effects
        tag.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(-5px) scale(1.05)';
            this.style.background = 'rgba(0, 38, 58, 0.5)';
            playSound('hover');
        });
        
        tag.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0) scale(1)';
            this.style.background = 'rgba(0, 38, 58, 0.3)';
        });
    });
    
    // Add click events to fish images
    fishImages.forEach(img => {
        img.addEventListener('click', function(e) {
            e.stopPropagation();
            hasUserInteracted = true;
            const slide = this.closest('sr7-slide');
            if (slide) {
                toggleInfoPanel(slide);
            }
            
            // Add ripple effect
            createRippleEffect(e, this);
        });
        
        // Enhanced hover effects for fish images
        img.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.08) rotate(2deg)';
            this.style.filter = 'brightness(1.1) contrast(1.05)';
            this.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
            playSound('hover');
        });
        
        img.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1) rotate(0deg)';
            this.style.filter = 'brightness(1) contrast(1)';
        });
    });
    
    // Close info panels when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.info-panel') && 
            !e.target.closest('.info-tag') && 
            !e.target.closest('sr7-img[id*="-8"]')) {
            closeAllInfoPanels();
            startAutoPlay();
        }
    });
}

function closeAllInfoPanels() {
    const infoPanels = document.querySelectorAll('.info-panel');
    infoPanels.forEach(panel => {
        panel.classList.remove('active');
        panel.style.opacity = '0';
        panel.style.visibility = 'hidden';
        panel.style.transform = 'translateY(-50%) translateX(20px)';
    });
}

// ==================== NAVIGATION FUNCTIONALITY ====================
function initializeNavigation() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    // Button click events
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            hasUserInteracted = true;
            if (typeof window.prevSlide === 'function') {
                window.prevSlide();
            }
            playSound('click');
        });
        
        // Add hover effect
        prevBtn.addEventListener('mouseenter', function() {
            this.style.color = '#f46100';
            this.style.transform = 'translateX(-3px)';
        });
        
        prevBtn.addEventListener('mouseleave', function() {
            this.style.color = '#f0ecdb';
            this.style.transform = 'translateX(0)';
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            hasUserInteracted = true;
            if (typeof window.nextSlide === 'function') {
                window.nextSlide();
            }
            playSound('click');
        });
        
        // Add hover effect
        nextBtn.addEventListener('mouseenter', function() {
            this.style.color = '#f46100';
            this.style.transform = 'translateX(3px)';
        });
        
        nextBtn.addEventListener('mouseleave', function() {
            this.style.color = '#f0ecdb';
            this.style.transform = 'translateX(0)';
        });
    }
    
    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        hasUserInteracted = true;
        
        switch(e.key) {
            case 'ArrowLeft':
                if (typeof window.prevSlide === 'function') {
                    window.prevSlide();
                }
                break;
            case 'ArrowRight':
                if (typeof window.nextSlide === 'function') {
                    window.nextSlide();
                }
                break;
            case 'Escape':
                closeAllInfoPanels();
                if (typeof window.closeMenu === 'function') {
                    window.closeMenu();
                }
                break;
            case ' ': // Spacebar
                e.preventDefault();
                if (typeof window.nextSlide === 'function') {
                    window.nextSlide();
                }
                break;
        }
    });
    
    // Touch/swipe support
    initializeTouchControls();
}

function initializeTouchControls() {
    const container = document.querySelector('#rs-fullblock');
    if (!container) return;
    
    container.addEventListener('touchstart', function(e) {
        SR7.touchStartX = e.touches[0].clientX;
    }, { passive: true });
    
    container.addEventListener('touchmove', function(e) {
        // Prevent scrolling during swipe
        if (Math.abs(SR7.touchStartX - e.touches[0].clientX) > 10) {
            e.preventDefault();
        }
    }, { passive: false });
    
    container.addEventListener('touchend', function(e) {
        SR7.touchEndX = e.changedTouches[0].clientX;
        handleSwipe();
    }, { passive: true });
    
    function handleSwipe() {
        const diff = SR7.touchStartX - SR7.touchEndX;
        const threshold = 80;
        
        if (Math.abs(diff) > threshold) {
            hasUserInteracted = true;
            
            if (diff > 0 && typeof window.nextSlide === 'function') {
                window.nextSlide();
            } else if (diff < 0 && typeof window.prevSlide === 'function') {
                window.prevSlide();
            }
        }
    }
}

// ==================== SOUND EFFECTS ====================
function initializeSoundEffects() {
    // Initialize audio context on first user interaction
    document.addEventListener('click', function() {
        if (!hasUserInteracted) {
            hasUserInteracted = true;
            initAudioContext();
        }
    }, { once: true });
}

function initAudioContext() {
    try {
        audioContext = new (AudioContext || webkitAudioContext)();
        
        if (audioContext.state === 'suspended') {
            audioContext.resume();
        }
    } catch (error) {
        console.log('Audio context not available:', error.message);
    }
}

function playSound(type) {
    if (!hasUserInteracted || !audioContext) return;
    
    try {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // Sound frequencies
        const frequencies = {
            click: 800,
            slide: 400,
            hover: 600,
            success: 1000,
            error: 300
        };
        
        oscillator.frequency.setValueAtTime(
            frequencies[type] || 500, 
            audioContext.currentTime
        );
        
        // Volume and duration
        gainNode.gain.setValueAtTime(0.02, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
        
    } catch (error) {
        // Silently fail if audio doesn't work
    }
}

// ==================== VISUAL EFFECTS ====================
function initializeVisualEffects() {
    // Add floating fish animation
    const fishImages = document.querySelectorAll('sr7-img[id*="-8"]');
    fishImages.forEach((img, index) => {
        img.style.animation = `float 4s ease-in-out infinite ${index * 0.7}s`;
    });
    
    // Add button hover effects
    const buttons = document.querySelectorAll('sr7-btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.02)';
            this.style.boxShadow = '0 8px 25px rgba(0,0,0,0.2)';
            this.style.filter = 'brightness(1.1)';
            playSound('hover');
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = 'none';
            this.style.filter = 'brightness(1)';
        });
        
        btn.addEventListener('click', function() {
            this.style.transform = 'translateY(1px) scale(0.98)';
            playSound('click');
            
            setTimeout(() => {
                this.style.transform = 'translateY(-3px) scale(1.02)';
            }, 150);
        });
    });
    
    // Add parallax scrolling effect
    initializeParallaxEffect();
}

function initializeParallaxEffect() {
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('sr7-bg');
        
        parallaxElements.forEach(element => {
            const speed = scrolled * 0.3;
            element.style.transform = `translateY(${speed}px)`;
        });
    });
}

function createRippleEffect(event, element) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    const size = 100;
    
    ripple.style.cssText = `
        position: absolute;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(255,255,255,0.4) 0%, transparent 70%);
        width: ${size}px;
        height: ${size}px;
        left: ${event.clientX - rect.left - size/2}px;
        top: ${event.clientY - rect.top - size/2}px;
        transform: scale(0);
        animation: rippleGrow 0.6s ease-out;
        pointer-events: none;
        z-index: 1000;
    `;
    
    element.style.position = 'relative';
    element.appendChild(ripple);
    
    setTimeout(() => {
        if (ripple.parentNode) {
            ripple.remove();
        }
    }, 600);
}

// ==================== PARTICLE EFFECTS ====================
function initializeParticleEffects() {
    // Create bubble particles for underwater effect
    function createBubble() {
        const bubble = document.createElement('div');
        const size = Math.random() * 8 + 4;
        
        bubble.style.cssText = `
            position: fixed;
            width: ${size}px;
            height: ${size}px;
            background: radial-gradient(circle, rgba(255,255,255,0.4), rgba(255,255,255,0.1));
            border-radius: 50%;
            pointer-events: none;
            z-index: 1;
            left: ${Math.random() * 100}vw;
            bottom: -20px;
            animation: bubbleFloat ${3 + Math.random() * 3}s linear infinite;
        `;
        
        document.body.appendChild(bubble);
        
        setTimeout(() => {
            if (bubble.parentNode) {
                bubble.remove();
            }
        }, 6000);
    }
    
    // Create bubbles periodically
    setInterval(createBubble, 3000);
    
    // Add caustic light effects
    addCausticEffects();
}

function addCausticEffects() {
    const slides = document.querySelectorAll('sr7-slide');
    
    slides.forEach(slide => {
        const caustics = document.createElement('div');
        caustics.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                radial-gradient(circle at 30% 40%, rgba(255,255,255,0.1) 2px, transparent 2px),
                radial-gradient(circle at 70% 80%, rgba(255,255,255,0.08) 1px, transparent 1px),
                radial-gradient(circle at 20% 90%, rgba(255,255,255,0.12) 1px, transparent 1px);
            animation: causticMove 12s ease-in-out infinite;
            pointer-events: none;
            z-index: 1;
        `;
        
        slide.style.position = 'relative';
        slide.appendChild(caustics);
    });
}

// ==================== ADVANCED ANIMATIONS ====================
function initializeAdvancedAnimations() {
    // Stagger animation for menu items
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
            }
        });
    });
    
    document.querySelectorAll('sr7-txt, sr7-img, sr7-btn').forEach(element => {
        observer.observe(element);
    });
}

// ==================== RESPONSIVE FEATURES ====================
function initializeResponsiveFeatures() {
    // Handle window resize
    window.addEventListener('resize', debounce(function() {
        adjustResponsiveElements();
    }, 250));
    
    // Initial responsive adjustments
    adjustResponsiveElements();
}

function adjustResponsiveElements() {
    const isMobile = window.innerWidth <= 768;
    const slides = document.querySelectorAll('sr7-slide');
    
    slides.forEach(slide => {
        const contentGroups = slide.querySelectorAll('sr7-grp[style*="width: 50%"]');
        
        contentGroups.forEach(group => {
            if (isMobile) {
                group.style.width = '100% !important';
                group.style.height = '50% !important';
            } else {
                group.style.width = '50%';
                group.style.height = 'auto';
            }
        });
        
        // Adjust font sizes for mobile
        const largeTitles = slide.querySelectorAll('sr7-txt[style*="font-size: 117px"], sr7-txt[style*="font-size: 65px"]');
        largeTitles.forEach(title => {
            if (isMobile) {
                const currentSize = parseInt(title.style.fontSize);
                title.style.fontSize = Math.max(currentSize * 0.5, 32) + 'px';
            }
        });
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ==================== IMAGE LOADING ====================
function fixImageLoading() {
    const bgImages = document.querySelectorAll('sr7-bg, sr7-img');
    
    bgImages.forEach(element => {
        const style = element.getAttribute('style') || '';
        const bgImageMatch = style.match(/background-image:\s*url\(['"]?([^'")]+)['"]?\)/);
        
        if (bgImageMatch) {
            const imageUrl = bgImageMatch[1];
            
            // Test image loading
            const testImg = new Image();
            
            testImg.onload = function() {
                element.style.backgroundImage = `url('${imageUrl}')`;
                element.style.backgroundSize = 'cover';
                element.style.backgroundPosition = 'center';
                element.style.backgroundRepeat = 'no-repeat';
                element.setAttribute('data-loaded', 'true');
            };
            
            testImg.onerror = function() {
                console.warn('Failed to load image:', imageUrl);
                createImageFallback(element);
            };
            
            testImg.src = imageUrl;
        } else {
            // No background image, create fallback
            createImageFallback(element);
        }
    });
    
    // Add fish placeholder content for images that don't load
    addFishPlaceholders();
}

function createImageFallback(element) {
    let fallbackGradient = 'linear-gradient(135deg, #008ca8, #f0ecdb)';
    
    if (element.id.includes('salmon')) {
        fallbackGradient = 'linear-gradient(135deg, #ff6b35, #ff8e35)';
    } else if (element.id.includes('halibut')) {
        fallbackGradient = 'linear-gradient(135deg, #4a90e2, #7bb3f0)';
    } else if (element.id.includes('tuna')) {
        fallbackGradient = 'linear-gradient(135deg, #e74c3c, #f39c12)';
    } else if (element.id.includes('seabass')) {
        fallbackGradient = 'linear-gradient(135deg, #2ecc71, #27ae60)';
    } else if (element.id.includes('mackerel')) {
        fallbackGradient = 'linear-gradient(135deg, #9b59b6, #8e44ad)';
    }
    
    element.style.background = fallbackGradient;
    element.setAttribute('data-loaded', 'fallback');
}

function addFishPlaceholders() {
    const fishImages = document.querySelectorAll('sr7-img[id*="-8"]');
    
    fishImages.forEach(img => {
        // Add fish icon and text overlay
        if (!img.querySelector('.fish-placeholder')) {
            const placeholder = document.createElement('div');
            placeholder.className = 'fish-placeholder';
            placeholder.innerHTML = `
                <div style="
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    color: white;
                    font-size: 48px;
                    text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
                    text-align: center;
                    pointer-events: none;
                    z-index: 10;
                ">
                    🐟
                    <div style="
                        font-size: 16px;
                        font-family: 'Epilogue', sans-serif;
                        margin-top: 10px;
                        font-weight: 600;
                        text-transform: uppercase;
                        letter-spacing: 1px;
                    ">
                        Click to see info
                    </div>
                </div>
            `;
            
            img.style.position = 'relative';
            img.appendChild(placeholder);
        }
    });
}

// ==================== ANIMATIONS & STYLES ====================
function addAnimations() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-8px) rotate(1deg); }
            66% { transform: translateY(-4px) rotate(-1deg); }
        }
        
        @keyframes bubbleFloat {
            0% { 
                transform: translateY(0) rotate(0deg); 
                opacity: 0; 
            }
            10% { opacity: 0.8; }
            90% { opacity: 0.8; }
            100% { 
                transform: translateY(-100vh) rotate(360deg); 
                opacity: 0; 
            }
        }
        
        @keyframes causticMove {
            0%, 100% { transform: translateX(0) translateY(0); }
            25% { transform: translateX(15px) translateY(-8px); }
            50% { transform: translateX(-8px) translateY(15px); }
            75% { transform: translateX(-12px) translateY(-12px); }
        }
        
        @keyframes rippleGrow {
            0% { 
                transform: scale(0); 
                opacity: 1; 
            }
            100% { 
                transform: scale(4); 
                opacity: 0; 
            }
        }
        
        @keyframes fadeInUp {
            0% { 
                transform: translateY(30px); 
                opacity: 0; 
            }
            100% { 
                transform: translateY(0); 
                opacity: 1; 
            }
        }
        
        @keyframes slideInLeft {
            0% { 
                transform: translateX(-100%); 
                opacity: 0; 
            }
            100% { 
                transform: translateX(0); 
                opacity: 1; 
            }
        }
        
        @keyframes slideInRight {
            0% { 
                transform: translateX(100%); 
                opacity: 0; 
            }
            100% { 
                transform: translateX(0); 
                opacity: 1; 
            }
        }
        
        @keyframes slideInFromRight {
            0% { 
                transform: translateX(50px); 
                opacity: 0; 
            }
            100% { 
                transform: translateX(0); 
                opacity: 1; 
            }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        @keyframes glow {
            0%, 100% { box-shadow: 0 0 5px rgba(244, 97, 0, 0.5); }
            50% { box-shadow: 0 0 20px rgba(244, 97, 0, 0.8); }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-2px); }
            75% { transform: translateX(2px); }
        }
        
        /* Apply animations to elements */
        sr7-slide[style*="visibility: visible"] sr7-grp {
            animation: slideInLeft 0.8s ease-out;
        }
        
        sr7-slide[style*="visibility: visible"] sr7-img {
            animation: fadeInUp 1s ease-out 0.3s both;
        }
        
        .info-tag:hover {
            animation: pulse 0.5s ease-in-out;
        }
        
        sr7-btn:active {
            transform: translateY(2px) scale(0.95) !important;
        }
        
        .menu-panel.active .menu-item {
            animation: slideInFromRight 0.5s ease-out both;
        }
        
        .menu-panel.active .menu-item:nth-child(1) { animation-delay: 0.1s; }
        .menu-panel.active .menu-item:nth-child(2) { animation-delay: 0.2s; }
        .menu-panel.active .menu-item:nth-child(3) { animation-delay: 0.3s; }
        .menu-panel.active .menu-item:nth-child(4) { animation-delay: 0.4s; }
        
        /* Enhanced hover effects */
        sr7-btn:hover {
            animation: glow 1s ease-in-out infinite;
        }
        
        .info-tag:active {
            animation: shake 0.3s ease-in-out;
        }
        
        /* Improved transitions */
        sr7-slide {
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        sr7-img, sr7-txt, sr7-btn {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .info-panel {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .menu-item {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* Loading states */
        sr7-img[data-loaded="false"] {
            opacity: 0.5;
            filter: blur(2px);
        }
        
        sr7-img[data-loaded="true"] {
            opacity: 1;
            filter: blur(0);
        }
        
        sr7-img[data-loaded="fallback"] {
            opacity: 1;
            filter: blur(0);
        }
        
        /* Responsive animations */
        @media (max-width: 768px) {
            @keyframes slideInLeft {
                0% { transform: translateY(-50%); opacity: 0; }
                100% { transform: translateY(0); opacity: 1; }
            }
            
            @keyframes slideInRight {
                0% { transform: translateY(50%); opacity: 0; }
                100% { transform: translateY(0); opacity: 1; }
            }
            
            .float {
                animation-duration: 2s !important;
            }
        }
        
        /* Accessibility improvements */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
        
        /* Focus styles */
        sr7-btn:focus,
        .nav-btn:focus,
        .info-tag:focus {
            outline: 2px solid #f46100;
            outline-offset: 2px;
        }
        
        /* Custom scrollbar */
        .info-panel::-webkit-scrollbar {
            width: 4px;
        }
        
        .info-panel::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.1);
            border-radius: 2px;
        }
        
        .info-panel::-webkit-scrollbar-thumb {
            background: rgba(244, 97, 0, 0.6);
            border-radius: 2px;
        }
        
        .info-panel::-webkit-scrollbar-thumb:hover {
            background: rgba(244, 97, 0, 0.8);
        }
    `;
    document.head.appendChild(style);
}

function addVisualEnhancements() {
    // Add performance optimization
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    
    if (prefersReducedMotion.matches) {
        document.body.classList.add('reduced-motion');
        return; // Skip heavy animations for users who prefer reduced motion
    }
    
    // Add mouse follow effect
    addMouseFollowEffect();
    
    // Add particle trail
    addParticleTrail();
    
    // Add advanced lighting effects
    addAdvancedLighting();
    
    // Add performance monitoring
    addPerformanceMonitoring();
}

function addMouseFollowEffect() {
    let mouseX = 0, mouseY = 0;
    let currentX = 0, currentY = 0;
    
    document.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    function animateMouseFollow() {
        currentX += (mouseX - currentX) * 0.1;
        currentY += (mouseY - currentY) * 0.1;
        
        // Apply subtle parallax to fish images
        const fishImages = document.querySelectorAll('sr7-img[id*="-8"]');
        fishImages.forEach((img, index) => {
            const rect = img.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            
            const deltaX = (currentX - centerX) * 0.02;
            const deltaY = (currentY - centerY) * 0.02;
            
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                img.style.transform += ` translate(${deltaX}px, ${deltaY}px)`;
            }
        });
        
        requestAnimationFrame(animateMouseFollow);
    }
    
    animateMouseFollow();
}

function addParticleTrail() {
    let particles = [];
    
    document.addEventListener('mousemove', function(e) {
        // Create particle on mouse move (throttled)
        if (Math.random() > 0.9) {
            createTrailParticle(e.clientX, e.clientY);
        }
    });
    
    function createTrailParticle(x, y) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: fixed;
            width: 4px;
            height: 4px;
            background: radial-gradient(circle, rgba(244, 97, 0, 0.8), transparent);
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            left: ${x}px;
            top: ${y}px;
            animation: particleFade 1s ease-out forwards;
        `;
        
        document.body.appendChild(particle);
        particles.push(particle);
        
        // Clean up old particles
        if (particles.length > 20) {
            const oldParticle = particles.shift();
            if (oldParticle && oldParticle.parentNode) {
                oldParticle.remove();
            }
        }
        
        setTimeout(() => {
            if (particle && particle.parentNode) {
                particle.remove();
                particles = particles.filter(p => p !== particle);
            }
        }, 1000);
    }
    
    // Add particle fade animation
    const particleStyle = document.createElement('style');
    particleStyle.textContent = `
        @keyframes particleFade {
            0% { opacity: 1; transform: scale(1); }
            100% { opacity: 0; transform: scale(0); }
        }
    `;
    document.head.appendChild(particleStyle);
}

function addAdvancedLighting() {
    // Create dynamic lighting overlay
    const lightingOverlay = document.createElement('div');
    lightingOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: radial-gradient(600px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), 
            rgba(255,255,255,0.05) 0%, 
            rgba(255,255,255,0.02) 40%, 
            transparent 80%);
        pointer-events: none;
        z-index: 2;
        transition: opacity 0.3s ease;
    `;
    
    document.body.appendChild(lightingOverlay);
    
    document.addEventListener('mousemove', function(e) {
        const x = (e.clientX / window.innerWidth) * 100;
        const y = (e.clientY / window.innerHeight) * 100;
        
        lightingOverlay.style.setProperty('--mouse-x', x + '%');
        lightingOverlay.style.setProperty('--mouse-y', y + '%');
    });
}

function addPerformanceMonitoring() {
    let frameCount = 0;
    let lastTime = performance.now();
    
    function measureFPS() {
        frameCount++;
        const currentTime = performance.now();
        
        if (currentTime - lastTime >= 1000) {
            const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
            
            // Adjust animations based on FPS
            if (fps < 30) {
                document.body.classList.add('low-performance');
                reduceAnimations();
            }
            
            frameCount = 0;
            lastTime = currentTime;
        }
        
        requestAnimationFrame(measureFPS);
    }
    
    measureFPS();
}

function reduceAnimations() {
    const style = document.createElement('style');
    style.textContent = `
        .low-performance * {
            animation-duration: 0.3s !important;
            transition-duration: 0.2s !important;
        }
        
        .low-performance .caustics,
        .low-performance .fish-placeholder {
            display: none !important;
        }
    `;
    document.head.appendChild(style);
}

// ==================== ERROR HANDLING ====================
function setupErrorHandling() {
    // Global error handler
    window.addEventListener('error', function(e) {
        console.warn('Error handled gracefully:', e.message);
        
        // Try to recover from common errors
        if (e.message.includes('Cannot read property')) {
            console.log('Attempting to reinitialize...');
            setTimeout(() => {
                try {
                    initializeSlider();
                } catch (err) {
                    console.warn('Recovery failed:', err.message);
                }
            }, 1000);
        }
        
        e.preventDefault();
        return true;
    });
    
    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', function(e) {
        console.warn('Promise rejection handled:', e.reason);
        e.preventDefault();
    });
    
    // Visibility change handler
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            stopAutoPlay();
        } else {
            startAutoPlay();
        }
    });
}

// ==================== ACCESSIBILITY FEATURES ====================
function initializeAccessibility() {
    // Add ARIA labels
    const slides = document.querySelectorAll('sr7-slide');
    slides.forEach((slide, index) => {
        slide.setAttribute('role', 'tabpanel');
        slide.setAttribute('aria-label', `Slide ${index + 1} of ${slides.length}`);
    });
    
    // Add keyboard navigation hints
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => {
        btn.setAttribute('role', 'button');
        btn.setAttribute('tabindex', '0');
    });
    
    // Add focus management
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
}

// ==================== UTILITY FUNCTIONS ====================
function throttle(func, delay) {
    let timeoutId;
    let lastExecTime = 0;
    
    return function(...args) {
        const currentTime = Date.now();
        
        if (currentTime - lastExecTime > delay) {
            func.apply(this, args);
            lastExecTime = currentTime;
        } else {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                func.apply(this, args);
                lastExecTime = Date.now();
            }, delay - (currentTime - lastExecTime));
        }
    };
}

function getRandomColor() {
    const colors = [
        '#ff6b35', '#ff8e35', '#4a90e2', '#7bb3f0',
        '#e74c3c', '#f39c12', '#2ecc71', '#27ae60',
        '#9b59b6', '#8e44ad', '#f46100', '#008ca8'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

// ==================== SR7 COMPATIBILITY ====================
// SR7 PMH compatibility (from original code)
SR7.PMH = SR7.PMH || {};
SR7.PMH["SR7_1837_1"] = {
    cn: 100,
    state: false,
    fn: function() {
        if (typeof _tpt !== 'undefined' && _tpt.prepareModuleHeight !== 'undefined') {
            _tpt.prepareModuleHeight({
                id: "SR7_1837_1",
                el: [900, 900, 767, 960, 720],
                type: 'standard',
                shdw: '0',
                gh: [900, 900, 768, 960, 720],
                gw: [1240, 1240, 1024, 778, 480],
                vpt: ['100px', '100px', '100px', '100px', '100px'],
                size: { fullWidth: true, fullHeight: true },
                fho: '#masthead,',
                mh: '0',
                onh: 0,
                onw: 0,
                bg: { color: '{"type":"solid","orig":"#001226","string":"rgba(0, 18, 38, 1)"}' }
            });
            SR7.PMH["SR7_1837_1"].state = true;
        } else if (SR7.PMH["SR7_1837_1"].cn-- > 0) {
            setTimeout(SR7.PMH["SR7_1837_1"].fn, 19);
        }
    }
};

// Execute PMH function
if (SR7.PMH["SR7_1837_1"]) {
    SR7.PMH["SR7_1837_1"].fn();
}

// ==================== CLEANUP ====================
window.addEventListener('beforeunload', function() {
    // Clean up intervals and timeouts
    if (SR7.autoPlayInterval) {
        clearInterval(SR7.autoPlayInterval);
    }
    
    // Clean up audio context
    if (audioContext && audioContext.state !== 'closed') {
        audioContext.close();
    }
    
    // Remove dynamic elements
    document.querySelectorAll('.water-ripple, .fish-placeholder div, .caustics').forEach(element => {
        if (element.parentNode) {
            element.remove();
        }
    });
    
    console.log('🐟 Seafood Store Template cleaned up successfully! 🐟');
});

// ==================== EXPORT FOR MODULES ====================
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        SR7,
        initializeSlider,
        initializeMenu,
        initializeInfoPanels,
        initializeNavigation,
        playSound,
        createRippleEffect
    };
}